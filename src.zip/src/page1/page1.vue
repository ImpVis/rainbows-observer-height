<template>
    <div>
        <!-- <iv-title-bar> Rainbow </iv-title-bar> -->
        <iv-visualisation :title="vis_name" :vue_config="vue_config" :page_number="1" >
            
            <template #hotspots>

                <iv-toggle-hotspot position="bottom" title="Settings">
                    <iv-slider name="Observer height above sea level" ref="slider" @sliderChanged="change" theme="Lime" :min="0" :max="50" :time_step="10" :init_val="0" :step="0.1" :tick_step="10" :playButton="true"/>
                </iv-toggle-hotspot>

                <!-- <iv-fixed-hotspot :noWastedSpace="true" position="bottom" style=" z-index: 2;" >
                     <iv-slider name="" ref="slider" @sliderChanged="change" theme="Lime" :min="0" :max="50" :init_val="0" :step="0.1" :tick_step="10" />
                    
                </iv-fixed-hotspot> -->

                <!-- <iv-toggle-hotspot position="right" title="Observer view">
                    <div id="2D_cont" style="display: inline-block; float=right">
                    <canvas id="canvas" float="right" width="0.29*window.innerWidth" height="0.23*window.innerHeight"   ></canvas>
                    </div>
                </iv-toggle-hotspot> -->

            </template> 
              

            <iv-pane position="left" format="push" :width=22>
                <iv-sidebar-content :showPagination="true">                     
                        <iv-sidebar-section title="Theory" icon="microscope" >
                            <p>
                                The dark blue square in the 3D diagram indicates the observer's position, with the black lines showing sun rays coming from infinity. Only
                                rays that can reach the observer are shown, and assume there are only water droplets in a plane perpendicular to the plane of the observer for simplicity.  
                            </p>           
                            <p>
                                The sun rays totally interally reflect through the water droplets, emerging at angles of 40 to 42 degrees (depending on the wavelength of light),
                                creating the different colour bands that we see. 
                            </p>
                            <p> 
                                The yellow cone indicates reflected rays that can reach the observer, with the angle between the centre of the cone and the slant ranging from 40-42 degrees.
                                This is why rainbows appear circular, as shown in the observer view diagram. 
                            </p> 
                            
                        </iv-sidebar-section>
                        <iv-sidebar-section title="Instructions" icon="question" theme="Lime" >
                            <p> 
                                How do you think the observer's view of the rainbow might change as their height above sea level rises?
                            </p>
                            <p>
                                Open the settings toggle at the bottom of the page to find out.
                            </p> 
                                   
                        </iv-sidebar-section>                                         
                    </iv-sidebar-content>
            </iv-pane>
            
            
            <div style="display: inline;">
                <div id="3D_cont" style="width: 0.45*window.innerWidth; height: 0.9*window.innerHeight; display: inline-block; float:left; padding-left:10px;">
                    <h4 text-align:center>3D diagram</h4>
                    <div id="3D" style="display: block;" float="left" width=100% height=100%> </div>
                </div>

                <div id="2D_cont" style="width: 0.45*window.innerWidth; display: inline-block; float:left; padding-left:10px;">
                    <h4 text-align:center>Observer's view</h4>
                    <canvas id="canvas" float="right" width="0.29*window.innerWidth" height="0.23*window.innerHeight"   ></canvas>
                </div>
            </div>


        </iv-visualisation>
    </div>
</template>
<script>


import vue_config from '../../vue.config.js';
import * as THREE from 'three';
import {OrbitControls} from 'three/examples/jsm/controls/OrbitControls.js';
        
    export default {
        name:"page1",
        data(){
            return {
                pageName:"page1",
                vue_config,
                vis_name: "Rainbows - observer height",
                obs_height: this.init_height,
                sliderupdate:this.init_slider
            }
        },
        props:{
            init_height:{default:0},
            init_slider:{default:false},
            // hotspotWidth:{default:"500px"}

        },
        methods: {
            change: function(val) {
                this.obs_height = val;
                this.sliderupdate = true;
        //          //console.log(this.obs_height)

            }
        },



        mounted() {
            let v=this;
            

            const renderer = new THREE.WebGLRenderer(); 
            renderer.setSize( 0.45* window.innerWidth, 0.45* window.innerHeight ); 
            document.getElementById('3D').appendChild( renderer.domElement ); 
            const scene = new THREE.Scene(); 
            scene.background = new THREE.Color(0xd5e8f2);
            // const axesHelper = new THREE.AxesHelper( 5 );
            // scene.add( axesHelper );
            const camera = new THREE.PerspectiveCamera( 45, window.innerWidth / window.innerHeight, 1, 500 ); 
            camera.position.set( -10, 4, 10 );
            camera.lookAt( 0, 0, 0 )
            const controls = new OrbitControls( camera, renderer.domElement );          
            controls.maxPolarAngle= 1.57;

            //////////////////// OBSERVER EYE ////////////////

            // const eye_text = new THREE.TextureLoader().load( 'assets/eye.png' );

            var planeMaterial = new THREE.MeshBasicMaterial({ color: 0x113d7a });
                // map:eye_text
            // img.map.needsUpdate = true; //ADDED

            // const material = new THREE.MeshBasicMaterial( {color: 0xffff00, side: THREE.DoubleSide} );


            // var plane = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.5),img);
            // plane.position.y=0.25;
            // plane.rotation.y = Math.PI/2 ;
            // plane.overdraw = true;
            // scene.add(plane);

            
            var planeGeometry = new THREE.PlaneGeometry(0.5, 0.5);
            // var texture = new THREE.TextureLoader().load( 'assets/eye.png' );
            // var planeMaterial = new THREE.MeshBasicMaterial( { map: texture } );


            var plane = new THREE.Mesh(planeGeometry, planeMaterial);
            plane.rotation.y = Math.PI/2 ;
            plane.doubleSided = true;
            plane.overdraw = true;
            scene.add(plane);



            var plane2 = new THREE.Mesh(planeGeometry, planeMaterial);
            plane2.position.x=0;
            plane2.rotation.y = 3*Math.PI/2 ;
            plane2.overdraw = true;
            scene.add(plane2);


            ///////////////////CONE///////////////////
        

            
            const distance= 5
            const radius = distance / Math.tan( 48 * Math.PI/ 180)
            const point_at_base=32

            const geo_cone = new THREE.ConeGeometry(radius, distance , point_at_base);
            const mat_cone = new THREE.MeshBasicMaterial({ color: 0xffb300, transparent: true ,opacity:0.2});
            const cone = new THREE.Mesh(geo_cone, mat_cone);
        

            cone.position.x=distance/2  ;
            cone.rotation.x = Math.PI;
            cone.rotation.z = Math.PI / 2;
            
            scene.add(cone);
            

            /////////////////// GROUND ///////////////////
    

            const geometry10 = new THREE.BoxGeometry( 15, radius, 20 );
            const material10 = new THREE.MeshBasicMaterial( {color: 0x82b592} );
            const cube = new THREE.Mesh( geometry10, material10 );
            cube.position.y=-radius/2;
            scene.add( cube );



            /////////////////// RAYS ///////////////////
                    
            const material2 = new THREE.LineBasicMaterial( { color: 0x000000 } );
            const numrays = 15
            const ang_increment= 2 * Math.PI /numrays

            var points = new Array(numrays)
            var geometries = new Array(numrays)
            var lines = new Array(numrays)
            const ar1_dir = new THREE.Vector3( 1, 0, 0 );
            var arrows = new Array(numrays)
        
            for (var i = 0; i < points.length; i++) {
            points[i] = new Array(3);
            const cur_angle = i * ang_increment
            points[i][0] = new THREE.Vector3( -2*distance, radius * Math.sin(cur_angle) , radius * Math.cos(cur_angle) ) ;
            points[i][1] = new THREE.Vector3( distance, radius * Math.sin(cur_angle), radius * Math.cos(cur_angle) ) ;
            points[i][2] =  new THREE.Vector3( 0, 0, 0 ) ;
            geometries[i] = new THREE.BufferGeometry().setFromPoints( points[i] );
            lines[i] =new THREE.Line( geometries[i], material2 );
            scene.add( lines[i] );  

            const origin = new THREE.Vector3( - 3, radius * Math.sin(cur_angle) , radius * Math.cos(cur_angle) );
            const arrowHelper = new THREE.ArrowHelper( ar1_dir, origin, 4, 0x000000);
            arrowHelper.headLength=0.1;
            arrowHelper.headWidth=0.5;
            scene.add( arrowHelper );


            const origin2 = points[i][1];
            const ar2_dir =  new THREE.Vector3( -distance, -radius * Math.sin(cur_angle), -radius * Math.cos(cur_angle) ) ;
            ar2_dir.normalize();
            arrows[i] = new THREE.ArrowHelper( ar2_dir, origin2, 4, 0x000000);
            arrows[i].headLength=0.1;
            arrows[i].headWidth=0.5;
            scene.add( arrows[i] );

            }

        
    

            ////////////////// 2D RAINBOW ///////////////////////
            var canvas = document.getElementById('canvas');
            canvas.width=0.3*window.innerWidth
            canvas.height=0.45*window.innerHeight

            var x = canvas.width/2;
            var y = canvas.height * 0.75;
            //var r = 195;
            var r = (canvas.height/2) * 0.75;

            
            function draw() {
                if (canvas.getContext) {
                    var ctx = canvas.getContext('2d');

                    //background
                    ctx.fillStyle = '#d5e8f2';
                    ctx.fillRect(0, 0, canvas.width , canvas.height);
                    ctx.beginPath();

                    // ctx.fillStyle = '0x82b592';
                    // ctx.fillRect(0, y, canvas.width , 50);
                    // ctx.beginPath();
                    
                    //rainbow
                    ctx.fillStyle = 'red';
                    ctx.arc(x, y, r, 0, Math.PI*2, true );
                    ctx.fill();

                    ctx.beginPath();
                    ctx.fillStyle = 'orange';
                    ctx.arc(x, y, r-(canvas.height*0.005), 0, Math.PI*2, true );
                    ctx.fill();

                    ctx.beginPath();
                    ctx.fillStyle = 'yellow';
                    ctx.arc(x, y, r-2*(canvas.height*0.005), 0, Math.PI*2, true );
                    ctx.fill();

                    ctx.beginPath();
                    ctx.fillStyle = 'green';
                    ctx.arc(x, y, r-3*(canvas.height*0.005), 0, Math.PI*2, true );
                    ctx.fill();

                    ctx.beginPath();
                    ctx.fillStyle = 'blue';
                    ctx.arc(x, y, r-4*(canvas.height*0.005), 0, Math.PI*2, true );
                    ctx.fill();

                    ctx.beginPath();
                    ctx.fillStyle = 'indigo';
                    ctx.arc(x, y, r-5*(canvas.height*0.005), 0, Math.PI*2, true );
                    ctx.fill();

                    ctx.beginPath();
                    ctx.fillStyle = 'violet';
                    ctx.arc(x, y, r-6*(canvas.height*0.005), 0, Math.PI*2, true );
                    ctx.fill();

                    ctx.beginPath();
                    ctx.fillStyle = '#d5e8f2';
                    ctx.arc(x, y, r-6*(canvas.height*0.005), 0, Math.PI*2, true );
                    ctx.fill();

                    //grass
                    ctx.fillStyle = '#82b592';
                    ctx.fillRect(0, canvas.height*0.875, canvas.width, canvas.height*0.125);



                    // // draw cloud
                    // ctx.beginPath();
                    // ctx.moveTo(170, 80);
                    // ctx.bezierCurveTo(130, 100, 130, 150, 230, 150);
                    // ctx.bezierCurveTo(250, 180, 320, 180, 340, 150);
                    // ctx.bezierCurveTo(420, 150, 420, 120, 390, 100);
                    // ctx.bezierCurveTo(430, 40, 370, 30, 340, 50);
                    // ctx.bezierCurveTo(320, 5, 250, 20, 250, 50);
                    // ctx.bezierCurveTo(200, 5, 150, 20, 170, 80);
                    // ctx.closePath();
                    // ctx.lineWidth = 5;
                    // ctx.fillStyle = '#8ED6FF';
                    // ctx.fill();
                    // ctx.strokeStyle = 'white';
                    // ctx.stroke();
                }    
            
            }
            draw();


            // ///testing///

            // var cont_2d = document.getElementById('2D_cont');

            // console.log(window.innerWidth)
            // console.log(window.innerHeight)
            // //console.log(document.getElementById("3D").clientWidth)
            // console.log(canvas.width)
            // console.log(cont_2d.width)

            ////////////// ANIMATE //////////////
            function animate() {       
                requestAnimationFrame( animate );
                controls.update();
                renderer.render( scene, camera );
                
                // var con_2d = document.getElementById('2D_cont');
                // con_2d.width=0.3*window.innerWidth
                // con_2d.height=0.47*window.innerHeight

            
                if (v.sliderupdate==true) {
                    cube.position.y=-radius/2  -v.obs_height/10;
                    camera.position.y= 4 - v.obs_height/10
                    

                    for (var i = 0; i < points.length; i++) {
                        if (points[i][1].y < -v.obs_height/10) {
                        lines[i].visible= false;
                        arrows[i].visible= false;
                        } else {
                        lines[i].visible= true;
                        arrows[i].visible= true;
                        }            
                    }
                    
                    y = (canvas.height * 0.75) -(canvas.height*0.005)*(v.obs_height);
                    //y = 300 -3.9*(v.obs_height);
                    
                    const ctx = canvas.getContext('2d');
                    ctx.clearRect(0, 0, canvas.width, canvas.height); 
                    draw();


                    v.sliderupdate=false;
                }
                
             }
            animate();


    }
    
    
    }

</script>
<style>
.iv-welcome-message{
    display:flex;
    flex-direction: column;
    align-items: center;
    margin-top: 50px;
}


#container {
    width: 300px;
    margin: auto;
}
#first {
    width: 100px;
    float: left;
    height: 300px;
}
#second {
    width: 200px;
    float: left;
    height: 300px;
}
#clear {
    clear: both;
}

h4 {text-align: center;} 
</style>